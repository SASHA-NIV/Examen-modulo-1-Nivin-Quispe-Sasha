package util;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.Charset;
import java.util.Base64;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;

public class AES {

    public static String cifrar(String encryptText, String key) {
        if (encryptText == null || key == null) {
            throw new IllegalArgumentException("No se puede cifrar valores nulos");
        }

        try {
            // Asegura que la clave tenga 16 caracteres (128 bits)
            byte[] keyBytes = key.getBytes(Charset.forName("UTF-8"));
            if (keyBytes.length != 16) {
                throw new IllegalArgumentException("La clave debe tener exactamente 16 caracteres para AES-128");
            }

            SecretKeySpec secretKey = new SecretKeySpec(keyBytes, "AES");

            Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
            cipher.init(Cipher.ENCRYPT_MODE, secretKey);
            byte[] encryptedBytes = cipher.doFinal(encryptText.getBytes(Charset.forName("UTF-8")));
            return Base64.getEncoder().encodeToString(encryptedBytes);

        } catch (NoSuchAlgorithmException | InvalidKeyException | NoSuchPaddingException
                | BadPaddingException | IllegalBlockSizeException e) {
            throw new RuntimeException("El cifrado falló", e);
        }
    }

    public static String decifrar(String decryptText, String key) {
        if (decryptText == null || key == null) {
            throw new IllegalArgumentException("No se puede descifrar valores nulos");
        }

        try {
            // Asegura que la clave tenga 16 caracteres
            byte[] keyBytes = key.getBytes(Charset.forName("UTF-8"));
            if (keyBytes.length != 16) {
                throw new IllegalArgumentException("La clave debe tener exactamente 16 caracteres para AES-128");
            }

            SecretKeySpec secretKey = new SecretKeySpec(keyBytes, "AES");

            Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
            cipher.init(Cipher.DECRYPT_MODE, secretKey);
            byte[] decryptedBytes = cipher.doFinal(Base64.getDecoder().decode(decryptText));
            return new String(decryptedBytes, Charset.forName("UTF-8"));

        } catch (NoSuchAlgorithmException | InvalidKeyException | NoSuchPaddingException
                | BadPaddingException | IllegalBlockSizeException e) {
            throw new RuntimeException("El descifrado falló", e);
        }
    }

    // Para probar
    public static void main(String[] args) {
        try {
            String textoOriginal = "1234";
            String clave = "la fe de cuto123"; // 16 caracteres

            String cifrado = cifrar(textoOriginal, clave);
            String descifrado = decifrar(cifrado, clave);

            System.out.println("Original:    " + textoOriginal);
            System.out.println("Cifrado AES: " + cifrado);
            System.out.println("Descifrado:  " + descifrado);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}