/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servlet;

import dao.UsuarioJpaController;
import dto.Usuario;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.JSONObject;
import util.AES;

/**
 *
 * @author SASHA
 */
@WebServlet(name = "CambiarClave", urlPatterns = {"/cambiarclave"})
public class CambiarClave extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        try (PrintWriter out = response.getWriter()) {
//            String user = request.getParameter("user");
//            String pass = request.getParameter("pass");
//            String newpass = request.getParameter("newpass");
//
//            UsuarioJpaController usuDAO = new UsuarioJpaController();
//            // Buscar el usuario por logiUsua
//            Usuario usuario = usuDAO.BuscarUsuarioxLogi(user); // Método para buscar el usuario
//
//            JSONObject jsonObject = new JSONObject();
//
//            // Verificar si el usuario existe y si la contraseña actual es correcta
//            if (usuario != null && usuario.getPassUsua().equals(pass)) {
//                // Cambiar la contraseña
//                String result = usuDAO.cambiarClave(usuario, newpass); // Método para cambiar la clave
//                if (result.equals("Clave cambiada exitosamente")) {
//                    jsonObject.put("resultado", "ok");
//                    jsonObject.put("mensaje", "Se cambió la clave");
//                } else {
//                    jsonObject.put("resultado", "error");
//                    jsonObject.put("mensaje", "No se pudo cambiar la clave");
//                }
//            } else {
//                jsonObject.put("resultado", "error");
//                jsonObject.put("mensaje", "Usuario no encontrado o contraseña actual incorrecta");
//            }
//            out.print(jsonObject.toString());
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        try (PrintWriter out = response.getWriter()) {
            String user = request.getParameter("logiUsua");
            String pass = request.getParameter("passUsua");
            String newpass = request.getParameter("newpass");

            UsuarioJpaController usuDAO = new UsuarioJpaController();
            Usuario usuario = usuDAO.BuscarUsuarioxLogi(user); // Método para buscar el usuario

            JSONObject jsonObject = new JSONObject();

            if (usuario != null) {
                // Cifrar el password que viene del Postman para poder compararlo
                String passCifrado = AES.cifrar(pass, "la fe de cuto123"); // Usa tu clave AES

                    if (usuario.getPassUsua().equals(passCifrado)) {
                    // Cambiar la contraseña
                    String result = usuDAO.cambiarClave(usuario, newpass);
                    if (result.equals("ok")) { // Ojo: tu cambiarClave devuelve este texto
                        jsonObject.put("resultado", "ok");
                        jsonObject.put("mensaje", "Se cambió la clave");
                    } else {
                        jsonObject.put("resultado", "error");
                        jsonObject.put("mensaje", "No se pudo cambiar la clave");
                    }
                } else {
                    jsonObject.put("resultado", "error");
                    jsonObject.put("mensaje", "Contraseña actual incorrecta");
                }
            } else {
                jsonObject.put("resultado", "error");
                jsonObject.put("mensaje", "Usuario no encontrado");
            }
            out.print(jsonObject.toString());
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
