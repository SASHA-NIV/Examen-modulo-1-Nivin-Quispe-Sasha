/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servlet;

import dao.EmpresaDAO;
import dao.UsuarioJpaController;
import dao.VistaUsuarioRolDAO;
import dto.Empresa;
import dto.Usuario;
import dto.VistaUsuarioRol;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author USER
 */
@WebServlet(name = "LoginServlet", urlPatterns = {"/loginservlet"})
public class LoginServlet extends HttpServlet {

    private UsuarioJpaController usuarioDAO;
    private final EntityManagerFactory emf;

    public LoginServlet() {
        EntityManagerFactory tempEmf = null;
        UsuarioJpaController tempUsuarioDAO = null;

        try {
            tempEmf = Persistence.createEntityManagerFactory("com.mycompany_Planilla_war_1.0-SNAPSHOTPU");
            tempUsuarioDAO = new UsuarioJpaController(tempEmf);
        } catch (Exception ex) {
            System.out.println("Error al inicializar DAOs: " + ex.getMessage());
        }

        this.emf = tempEmf;
        this.usuarioDAO = tempUsuarioDAO;
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String logiUsua = request.getParameter("logiUsua");
        String passUsua = request.getParameter("passUsua");

        if (usuarioDAO == null) {
            response.getWriter().print("Error de configuración del servidor");
            return;
        }

        Usuario usuario = usuarioDAO.validar(logiUsua, passUsua);

        response.setContentType("text/plain");
        PrintWriter out = response.getWriter();

        if (usuario != null) {
            // Cargar la empresa por defecto
                HttpSession session = request.getSession();
                session.setAttribute("codiUsua", usuario.getCodiUsua());
                session.setAttribute("logiUsua", usuario.getLogiUsua());
                session.setAttribute("nombUsua", usuario.getNombUsua());
                session.setAttribute("codiRol", usuario.getCodiRol());
                
                out.print("success");
        } else {
            out.print("error");
        }
    }
}
